# jQuery (Project 1)

This project will give you an opprotunity to start practicing with jQuery. 

> Reminder: Solution Guide is provided for this project.
